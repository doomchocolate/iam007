define(function() {

	function Foobar( foo, bar ) {
		return foo + bar;
	}

	return Foobar;

});
