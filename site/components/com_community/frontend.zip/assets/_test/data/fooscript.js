window.Foobar = function( foo, bar ) {
	return foo + bar;
}
